meetUpRider

- Lista de Dependências

API: GraphViewer - https://github.com/STEMS-group/GraphViewer
Ficheiros de Input: Ficheiros que contêm informação dos mapas OSM e GridGraphs, informação de passageiros, carros e condutor


- Instruções de Compilação

O projeto deve ser aberto com o CLion usando a opção "Import Project".
Após ser importado serão carregados os ficheiros de forma a estarem prontos a executar.

Aviso:
A entrega foi feita de modo a ser compatível com o sistema operativo Windows,
caso esteja a utilizar alguma distribuição de Linux comente ou apague a seguinte linha do ficheiro CMakeLists.txt
"link_libraries(ws2_32 wsock32)"

